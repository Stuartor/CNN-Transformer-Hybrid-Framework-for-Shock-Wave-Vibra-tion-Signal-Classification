# 爆破振动 CNN–Transformer 论文复现包（中文说明）

本包的核心是你**最后正式用于论文的公平实验**，并非早期试验结果。你上传的三个原始 `.py` 文件均**原样保留**，另外增加命令行便携入口和图表重绘工具。

## 一、三个原始文件有什么区别？

- **`train_revision_final_fair.py`：最终论文正式代码。** 四种主模型（CNN、CNN-LSTM、Transformer、CNN-Transformer）都不使用 weighted sampling；CNN-Transformer 额外单独测试 weighted sampler 作为消融；按 120 个真实物理事件进行五折分组验证。论文的主要结果来自该文件。
- **`train_revision_nested_event_cv.py`：旧版分组实验（保留备查）。** 这版训练策略不符合最终主对比的“全部无 sampler”设定，不能用它生成的结果冒充最终论文结果。
- **`generate_manuscript_figures_from_revision_results_FIXED.py`：旧版结果的后处理工具。** 它面向 `revision_results/`，不适用于最终 `revision_results_fair/` 里的模型命名。最终实验已自带绘图，已有最终 CSV 时还可以使用 `tools/replot_final_figures.py`。

## 二、原始现场数据不在 ZIP 内

四个 Excel 数据文件没有上传，不能假装已经打包了数据。请将原始文件放入 `data/`：

```text
data/
  管道爆破.xlsx
  隧道爆破.xlsx
  塌落振动.xlsx
  台阶爆破.xlsx
```

四个文件**均没有表头**，每个 90 列；每相邻的三列依次为同一个真实事件的 X、Y、Z；每类 30 个事件。四类单分量长度分别为 80,000、8,000、160,000、16,000 点；采样率 2 kHz。应得到 120 个真实事件、360 个分量序列、11,880 个 1 秒无重叠片段。

## 三、环境安装（建议使用你原来的 Anaconda 环境）

```powershell
conda create -n blasting-repro python=3.9 -y
conda activate blasting-repro
python -m pip install -r requirements.txt
```

如果已在 `lapdepth` 等现有 CUDA 环境正常跑过，建议保留原来的 PyTorch 安装，**不必为了本包随意重装 CUDA/PyTorch**。`requirements.txt` 是兼容版本建议，不是论文当时环境的精确 `pip freeze`。请使用下列命令记录实际环境：

```powershell
python tools/environment_report.py --output environment_actual.json
python -m pip freeze > pip_freeze_actual.txt
```

## 四、正式复现流程

首先检查数据文件格式：

```powershell
python tools/validate_data.py --data-dir data
python tests/smoke_test.py
```

**推荐运行入口**（无需修改三个原始代码的 Windows 绝对路径）：

```powershell
python tools/run_final.py --data-dir data --output-dir revision_results_fair
```

如果 Excel 仍保存在 `D:\2\各类振动`，使用：

```powershell
python tools/run_final.py --data-dir "D:\2\各类振动" --output-dir revision_results_fair
```

也可以打开**原始** `train_revision_final_fair.py`，修改第一个配置参数 `BASE_PATH`，直接运行 `python train_revision_final_fair.py`。不要把旧版 `train_revision_nested_event_cv.py` 当成最终训练程序。

训练输出为 `revision_results_fair/`，其中 `summary_mean_std.csv` 为五折平均 ± 样本标准差，`oof_metrics.csv` 为合并全部独立测试预测后的整体 OOF 指标，两者不能混写。原始最终代码运行结束后将自动在 `manuscript_figures/` 内生成所需图片（PNG/PDF）与论文数据表。

如已完成训练而仅需要重新生成最终论文图：

```powershell
python tools/replot_final_figures.py --results-dir revision_results_fair
```

**特别提醒**：最终模型的 `CNN-Transformer` 是*不使用 weighted sampler* 的主模型，五折分段级 Accuracy 约 **97.97% ± 0.76%**、Macro-F1 约 **96.53% ± 1.11%**。单独加权采样的消融版本 Macro-F1 约 **97.17% ± 1.45%**。绝不能把旧版 `CNN-Transformer (no sampler)` 的数字与最终公平实验结果混成一张表。

## 五、数据、代码和可重复性说明

- 没有现场 Excel 时，可运行 `python tests/smoke_test.py` 验证程序关键模块，但这**不等于复现论文准确率**。
- 完整数值复现还需要原始 Excel 数据，最好保留最终折分配、每折预测、模型权重、软件版本与 CUDA/GPU 信息。
- 原程序使用固定随机种子及 cuDNN 确定性选项，但不同 GPU / PyTorch 版本仍可能存在差异。
- 本包中的三个原始脚本未改动；`MANIFEST_SHA256.txt` 可用于核对文件一致性。
- 发布现场数据之前请确认企业/施工单位的授权，以及是否包含敏感工地信息。
