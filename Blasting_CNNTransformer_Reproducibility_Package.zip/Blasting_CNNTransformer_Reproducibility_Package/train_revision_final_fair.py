# -*- coding: utf-8 -*-
"""
Final revision experiment for:
A CNN–Transformer Hybrid Framework for Shock Wave Vibration Signal Classification
in Blasting Engineering

Key changes vs. the original script:
1) Physical-event grouped outer 5-fold CV: X/Y/Z from the same acquisition
   always stay in the same split.
2) Inner event-level validation for early stopping: the outer test fold is
   never used for model selection.
3) Fair baselines: CNN, CNN-LSTM, and a patch-based Transformer baseline.
4) Weighted-sampler ablation for the proposed CNN–Transformer.
5) Evaluation at segment, component-sequence, and physical-event levels.
6) Accuracy, Macro-F1, Weighted-F1, Balanced Accuracy, per-class metrics,
   parameter count, training time, and inference time.
7) Fixed random seeds and saved split assignments/predictions.

DATA ASSUMPTION CONFIRMED BY USER
---------------------------------
Each class XLSX contains 90 columns ordered as:
    Event 01: X, Y, Z
    Event 02: X, Y, Z
    ...
    Event 30: X, Y, Z
Thus there are 30 physical events/class, 120 events total, and
360 component-wise one-dimensional sequences total.
"""

import os
import re
import copy
import time
import random
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit


# ============================================================
# 0. Configuration
# ============================================================

BASE_PATH = r"D:\2\各类振动"

CATEGORIES_CN = ["管道爆破", "隧道爆破", "塌落振动", "台阶爆破"]
CATEGORY_NAMES_EN = [
    "Pipeline Blast",
    "Tunnel Blast",
    "Collapse Vibration",
    "Bench Blast",
]
AXIS_ORDER = ["X", "Y", "Z"]

FS = 2000
WINDOW_SIZE = 2000
STRIDE = 2000

N_CLASSES = 4
N_FOLDS = 5
INNER_VAL_RATIO = 0.20
SEED = 42

D_MODEL = 64
NHEAD = 4
NUM_LAYERS = 2
FFN_DIM = 256
CNN_CHANNELS = [32, 64, 128, 256]
CNN_SEQUENCE_LEN = 64

PATCH_SIZE = 20  # 2000 / 20 = 100 tokens

BATCH_SIZE = 32
NUM_EPOCHS = 40
PATIENCE = 10
LEARNING_RATE = 5e-4
WEIGHT_DECAY = 0.01
T_MAX = 15
GRAD_CLIP_NORM = 1.0

OUTPUT_DIR = Path("revision_results_fair")
CHECKPOINT_DIR = OUTPUT_DIR / "checkpoints"
HISTORY_DIR = OUTPUT_DIR / "histories"
PREDICTION_DIR = OUTPUT_DIR / "predictions"
FIGURE_DIR = OUTPUT_DIR / "figures"

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ============================================================
# 1. Reproducibility
# ============================================================

def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def sanitize_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).replace(" ", "_")


def ensure_output_dirs() -> None:
    for p in [OUTPUT_DIR, CHECKPOINT_DIR, HISTORY_DIR, PREDICTION_DIR, FIGURE_DIR]:
        p.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. Load event-grouped X/Y/Z component sequences
# ============================================================

def _clean_excel_signal(values, file_path, col_idx):
    s = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=np.float32)
    finite = np.isfinite(s)
    if not finite.any():
        raise ValueError(f"No numeric data in {file_path}, column {col_idx + 1}")
    last_valid = np.where(finite)[0][-1]
    s = s[: last_valid + 1]
    if not np.isfinite(s).all():
        bad = np.where(~np.isfinite(s))[0][:10]
        raise ValueError(
            f"Internal NaN/Inf in {file_path}, column {col_idx + 1}, "
            f"indices {bad.tolist()}"
        )
    return s


def load_component_sequences(base_path=BASE_PATH):
    records = []
    event_rows = []

    print("=" * 80)
    print("DATA LOADING")
    print("=" * 80)

    for label, category in enumerate(CATEGORIES_CN):
        file_path = os.path.join(base_path, f"{category}.xlsx")
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Missing data file: {file_path}")

        df = pd.read_excel(file_path, header=None)
        n_cols = df.shape[1]

        if n_cols % 3 != 0:
            raise ValueError(
                f"{category}.xlsx has {n_cols} columns; expected a multiple of 3."
            )

        n_events = n_cols // 3
        print(f"\n{category}: {n_cols} columns -> {n_events} physical events")

        for e in range(n_events):
            event_id = f"C{label}_E{e + 1:03d}"
            event_rows.append(
                {
                    "event_id": event_id,
                    "label": label,
                    "class_name": CATEGORY_NAMES_EN[label],
                    "event_local_id": e + 1,
                }
            )

            lengths = []
            for axis_idx, axis_name in enumerate(AXIS_ORDER):
                col_idx = e * 3 + axis_idx
                signal = _clean_excel_signal(
                    df.iloc[:, col_idx].values, file_path, col_idx
                )
                lengths.append(len(signal))

                records.append(
                    {
                        "signal": signal,
                        "label": label,
                        "class_name": CATEGORY_NAMES_EN[label],
                        "event_id": event_id,
                        "event_local_id": e + 1,
                        "axis": axis_name,
                        "sequence_id": f"{event_id}_{axis_name}",
                        "source_column": col_idx + 1,
                    }
                )

            if len(set(lengths)) != 1:
                raise ValueError(
                    f"X/Y/Z lengths differ in {category}, event {e + 1}: {lengths}"
                )

    events_df = pd.DataFrame(event_rows).drop_duplicates("event_id").reset_index(drop=True)

    print("\nDataset summary:")
    print(f"  Physical events: {len(events_df)}")
    print(f"  Component sequences: {len(records)}")
    print(events_df.groupby(["label", "class_name"]).size())

    counts = events_df.groupby("label").size().to_dict()
    if any(counts.get(c, 0) != 30 for c in range(N_CLASSES)):
        print(f"WARNING: expected 30 events/class, observed {counts}")

    return records, events_df


# ============================================================
# 3. Segmentation and metadata retention
# ============================================================

def select_records(records, event_ids):
    ids = set(event_ids)
    return [r for r in records if r["event_id"] in ids]


def segment_records(records, window_size=WINDOW_SIZE, stride=STRIDE):
    xs, ys = [], []
    event_ids, sequence_ids, axes, segment_indices = [], [], [], []

    for rec in records:
        sig = rec["signal"]
        if len(sig) < window_size:
            raise ValueError(
                f"{rec['sequence_id']} is shorter than WINDOW_SIZE={window_size}."
            )

        local_idx = 0
        for start in range(0, len(sig) - window_size + 1, stride):
            seg = sig[start : start + window_size].astype(np.float32, copy=True)
            seg = (seg - seg.mean()) / (seg.std() + 1e-8)

            xs.append(seg[:, None])
            ys.append(rec["label"])
            event_ids.append(rec["event_id"])
            sequence_ids.append(rec["sequence_id"])
            axes.append(rec["axis"])
            segment_indices.append(local_idx)
            local_idx += 1

    return {
        "x": np.asarray(xs, dtype=np.float32),
        "y": np.asarray(ys, dtype=np.int64),
        "event_id": np.asarray(event_ids, dtype=object),
        "sequence_id": np.asarray(sequence_ids, dtype=object),
        "axis": np.asarray(axes, dtype=object),
        "segment_index": np.asarray(segment_indices, dtype=np.int64),
    }


class VibrationDataset(Dataset):
    def __init__(self, bundle):
        self.x = torch.from_numpy(bundle["x"]).float()
        self.y = torch.from_numpy(bundle["y"]).long()

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx], idx


# ============================================================
# 4. Models
# ============================================================

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.2, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32)
            * (-np.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return self.dropout(x + self.pe[:, : x.size(1), :])


class CNNBackbone(nn.Module):
    def __init__(self, output_seq_len=CNN_SEQUENCE_LEN):
        super().__init__()
        c1, c2, c3, c4 = CNN_CHANNELS
        self.net = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=7, padding=3),
            nn.BatchNorm1d(c1), nn.ReLU(), nn.MaxPool1d(2),

            nn.Conv1d(c1, c2, kernel_size=5, padding=2),
            nn.BatchNorm1d(c2), nn.ReLU(), nn.MaxPool1d(2),

            nn.Conv1d(c2, c3, kernel_size=3, padding=1),
            nn.BatchNorm1d(c3), nn.ReLU(), nn.MaxPool1d(2),

            nn.Conv1d(c3, c4, kernel_size=3, padding=1),
            nn.BatchNorm1d(c4), nn.ReLU(),

            nn.AdaptiveAvgPool1d(output_seq_len),
        )

    def forward(self, x):
        return self.net(x.transpose(1, 2))


class ClassifierHead(nn.Module):
    def __init__(self, in_dim=D_MODEL, num_classes=N_CLASSES):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(64, num_classes),
        )

    def forward(self, x):
        return self.net(x)


class CNNOnly(nn.Module):
    """CNN ablation with fair temporal mean pooling."""
    def __init__(self, num_classes=N_CLASSES):
        super().__init__()
        self.backbone = CNNBackbone()
        self.projection = nn.Linear(CNN_CHANNELS[-1], D_MODEL)
        self.classifier = ClassifierHead(D_MODEL, num_classes)

    def forward(self, x):
        f = self.backbone(x).transpose(1, 2)
        f = self.projection(f)
        return self.classifier(f.mean(dim=1))


class CNNLSTM(nn.Module):
    def __init__(self, num_classes=N_CLASSES):
        super().__init__()
        self.backbone = CNNBackbone()
        self.projection = nn.Linear(CNN_CHANNELS[-1], D_MODEL)
        self.lstm = nn.LSTM(
            input_size=D_MODEL,
            hidden_size=D_MODEL,
            num_layers=1,
            batch_first=True,
            bidirectional=False,
        )
        self.classifier = ClassifierHead(D_MODEL, num_classes)

    def forward(self, x):
        f = self.projection(self.backbone(x).transpose(1, 2))
        _, (h_n, _) = self.lstm(f)
        return self.classifier(h_n[-1])


class PatchTransformer(nn.Module):
    """
    Transformer baseline with non-convolutional patch embedding.
    """
    def __init__(
        self,
        num_classes=N_CLASSES,
        patch_size=PATCH_SIZE,
        d_model=D_MODEL,
        nhead=NHEAD,
        num_layers=NUM_LAYERS,
    ):
        super().__init__()
        if WINDOW_SIZE % patch_size != 0:
            raise ValueError("WINDOW_SIZE must be divisible by PATCH_SIZE.")

        self.patch_size = patch_size
        self.patch_projection = nn.Linear(patch_size, d_model)
        self.pos_encoder = PositionalEncoding(d_model, dropout=0.2)

        enc = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=FFN_DIM,
            dropout=0.2,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.classifier = ClassifierHead(d_model, num_classes)

    def forward(self, x):
        x = x.squeeze(-1)
        b, length = x.shape
        n_patches = length // self.patch_size
        x = x[:, : n_patches * self.patch_size]
        x = x.reshape(b, n_patches, self.patch_size)
        x = self.patch_projection(x)
        x = self.pos_encoder(x)
        x = self.transformer(x)
        return self.classifier(x.mean(dim=1))


class CNNTransformer(nn.Module):
    """
    Proposed model:
    CNN -> projection -> positional encoding -> Transformer -> temporal mean pooling.

    IMPORTANT:
    This final revision uses mean pooling after the Transformer, not h_T.
    If these results are used in the paper, Section 2.5 and Eq. (12) must be
    changed to z = (1/T) * sum_t h_t.
    """
    def __init__(
        self,
        num_classes=N_CLASSES,
        d_model=D_MODEL,
        nhead=NHEAD,
        num_layers=NUM_LAYERS,
    ):
        super().__init__()
        self.backbone = CNNBackbone()
        self.projection = nn.Linear(CNN_CHANNELS[-1], d_model)
        self.pos_encoder = PositionalEncoding(d_model, dropout=0.2)

        enc = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=FFN_DIM,
            dropout=0.2,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.classifier = ClassifierHead(d_model, num_classes)

    def forward(self, x):
        f = self.backbone(x).transpose(1, 2)
        f = self.projection(f)
        f = self.pos_encoder(f)
        f = self.transformer(f)
        return self.classifier(f.mean(dim=1))


# ============================================================
# 5. Metrics and hierarchical aggregation
# ============================================================

def compute_metrics(y_true, y_pred):
    macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(
        y_true, y_pred,
        labels=np.arange(N_CLASSES),
        average="macro",
        zero_division=0,
    )
    _, _, weighted_f1, _ = precision_recall_fscore_support(
        y_true, y_pred,
        labels=np.arange(N_CLASSES),
        average="weighted",
        zero_division=0,
    )
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_precision": macro_p,
        "macro_recall": macro_r,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
    }


def per_class_metrics_dataframe(y_true, y_pred, model_name, level, fold):
    p, r, f1, support = precision_recall_fscore_support(
        y_true, y_pred,
        labels=np.arange(N_CLASSES),
        average=None,
        zero_division=0,
    )
    rows = []
    for c in range(N_CLASSES):
        rows.append({
            "model": model_name,
            "level": level,
            "fold": fold,
            "class_index": c,
            "class_name": CATEGORY_NAMES_EN[c],
            "precision": p[c],
            "recall": r[c],
            "f1": f1[c],
            "support": int(support[c]),
        })
    return pd.DataFrame(rows)


def prediction_dataframe(bundle, probs):
    df = pd.DataFrame({
        "label": bundle["y"],
        "pred": probs.argmax(axis=1),
        "event_id": bundle["event_id"],
        "sequence_id": bundle["sequence_id"],
        "axis": bundle["axis"],
        "segment_index": bundle["segment_index"],
    })
    for c in range(N_CLASSES):
        df[f"prob_{c}"] = probs[:, c]
    return df


def aggregate_component_predictions(segment_df):
    prob_cols = [f"prob_{c}" for c in range(N_CLASSES)]
    rows = []

    for sequence_id, g in segment_df.groupby("sequence_id", sort=False):
        labels = g["label"].unique()
        events = g["event_id"].unique()
        axes = g["axis"].unique()
        if len(labels) != 1 or len(events) != 1 or len(axes) != 1:
            raise RuntimeError(f"Inconsistent metadata in {sequence_id}")

        prob = g[prob_cols].mean(axis=0).to_numpy()
        row = {
            "sequence_id": sequence_id,
            "event_id": events[0],
            "axis": axes[0],
            "label": int(labels[0]),
            "pred": int(prob.argmax()),
            "n_segments": len(g),
        }
        for c in range(N_CLASSES):
            row[f"prob_{c}"] = prob[c]
        rows.append(row)

    return pd.DataFrame(rows)


def aggregate_event_predictions(component_df):
    prob_cols = [f"prob_{c}" for c in range(N_CLASSES)]
    rows = []

    for event_id, g in component_df.groupby("event_id", sort=False):
        labels = g["label"].unique()
        if len(labels) != 1:
            raise RuntimeError(f"Inconsistent labels in event {event_id}")
        if g["axis"].nunique() != 3:
            raise RuntimeError(
                f"Event {event_id} does not contain all three axes: "
                f"{sorted(g['axis'].unique().tolist())}"
            )

        # Equal weighting of X/Y/Z component-level probability vectors.
        prob = g[prob_cols].mean(axis=0).to_numpy()
        row = {
            "event_id": event_id,
            "label": int(labels[0]),
            "pred": int(prob.argmax()),
            "n_axes": 3,
        }
        for c in range(N_CLASSES):
            row[f"prob_{c}"] = prob[c]
        rows.append(row)

    return pd.DataFrame(rows)


# ============================================================
# 6. DataLoader, training and evaluation
# ============================================================

def make_train_loader(bundle, weighted_sampling, seed):
    dataset = VibrationDataset(bundle)
    generator = torch.Generator().manual_seed(seed)

    if weighted_sampling:
        y = bundle["y"]
        counts = np.bincount(y, minlength=N_CLASSES).astype(np.float64)
        if np.any(counts == 0):
            raise ValueError(f"Training split misses a class: {counts}")

        class_weights = 1.0 / counts
        sample_weights = class_weights[y]

        sampler = WeightedRandomSampler(
            weights=torch.as_tensor(sample_weights, dtype=torch.double),
            num_samples=len(sample_weights),
            replacement=True,
            generator=generator,
        )
        return DataLoader(
            dataset,
            batch_size=BATCH_SIZE,
            sampler=sampler,
            drop_last=True,
            num_workers=0,
            pin_memory=torch.cuda.is_available(),
        )

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        generator=generator,
        drop_last=True,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )


def make_eval_loader(bundle):
    return DataLoader(
        VibrationDataset(bundle),
        batch_size=BATCH_SIZE,
        shuffle=False,
        drop_last=False,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )


def evaluate_loader(model, loader):
    model.eval()
    all_probs, all_true, all_idx = [], [], []

    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t0 = time.perf_counter()

    with torch.no_grad():
        for x, y, idx in loader:
            x = x.to(DEVICE, non_blocking=True)
            logits = model(x)
            probs = torch.softmax(logits, dim=1)

            all_probs.append(probs.cpu().numpy())
            all_true.append(y.numpy())
            all_idx.append(idx.numpy())

    if torch.cuda.is_available():
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - t0

    probs = np.concatenate(all_probs)
    y_true = np.concatenate(all_true)
    idx = np.concatenate(all_idx)

    order = np.argsort(idx)
    probs = probs[order]
    y_true = y_true[order]
    y_pred = probs.argmax(axis=1)

    return {
        "probs": probs,
        "y_true": y_true,
        "y_pred": y_pred,
        "metrics": compute_metrics(y_true, y_pred),
        "elapsed_s": elapsed,
        "ms_per_sample": 1000.0 * elapsed / max(len(y_true), 1),
    }


def train_with_inner_validation(
    model,
    train_bundle,
    val_bundle,
    weighted_sampling,
    seed,
    model_name,
    fold,
):
    """
    Early stopping uses only the inner validation set.
    The outer test set is not available inside this function.
    """
    set_global_seed(seed)

    train_loader = make_train_loader(train_bundle, weighted_sampling, seed)
    val_loader = make_eval_loader(val_bundle)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=T_MAX)

    best_val_macro_f1 = -np.inf
    best_state = None
    best_epoch = 0
    patience_counter = 0
    history = []

    t0 = time.perf_counter()

    for epoch in range(1, NUM_EPOCHS + 1):
        model.train()
        total, correct, loss_sum = 0, 0, 0.0

        for x, y, _ in train_loader:
            x = x.to(DEVICE, non_blocking=True)
            y = y.to(DEVICE, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()

            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP_NORM)
            optimizer.step()

            loss_sum += loss.item() * y.size(0)
            total += y.size(0)
            correct += (logits.argmax(dim=1) == y).sum().item()

        scheduler.step()

        train_loss = loss_sum / max(total, 1)
        train_acc = correct / max(total, 1)

        val_result = evaluate_loader(model, val_loader)
        vm = val_result["metrics"]

        history.append({
            "epoch": epoch,
            "train_loss": train_loss,
            "train_accuracy": train_acc,
            "val_accuracy": vm["accuracy"],
            "val_macro_f1": vm["macro_f1"],
            "val_weighted_f1": vm["weighted_f1"],
            "lr": optimizer.param_groups[0]["lr"],
        })

        if vm["macro_f1"] > best_val_macro_f1 + 1e-8:
            best_val_macro_f1 = vm["macro_f1"]
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            patience_counter = 0
        else:
            patience_counter += 1

        if epoch == 1 or epoch % 5 == 0:
            print(
                f"      Epoch {epoch:02d}/{NUM_EPOCHS} | "
                f"Loss={train_loss:.4f} | "
                f"TrainAcc={train_acc*100:.2f}% | "
                f"ValAcc={vm['accuracy']*100:.2f}% | "
                f"ValMacroF1={vm['macro_f1']*100:.2f}%"
            )

        if patience_counter >= PATIENCE:
            print(
                f"      Early stop at epoch {epoch}; "
                f"best epoch={best_epoch}, "
                f"best inner-val Macro-F1={best_val_macro_f1*100:.2f}%"
            )
            break

    train_time_s = time.perf_counter() - t0

    if best_state is None:
        raise RuntimeError("No best model state was saved.")

    model.load_state_dict(best_state)

    hist_path = HISTORY_DIR / f"fold{fold}_{sanitize_filename(model_name)}_history.csv"
    pd.DataFrame(history).to_csv(hist_path, index=False)

    ckpt_path = CHECKPOINT_DIR / f"fold{fold}_{sanitize_filename(model_name)}.pt"
    torch.save(
        {
            "model_state_dict": best_state,
            "best_epoch": best_epoch,
            "best_inner_val_macro_f1": best_val_macro_f1,
            "seed": seed,
        },
        ckpt_path,
    )

    return model, {
        "best_epoch": best_epoch,
        "best_inner_val_macro_f1": best_val_macro_f1,
        "train_time_s": train_time_s,
    }


# ============================================================
# 7. Plotting
# ============================================================

def plot_confusion(cm, title, save_path):
    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(cm)

    ax.set_xticks(np.arange(N_CLASSES))
    ax.set_yticks(np.arange(N_CLASSES))
    ax.set_xticklabels(CATEGORY_NAMES_EN, rotation=30, ha="right")
    ax.set_yticklabels(CATEGORY_NAMES_EN)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title(title)

    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center")

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_summary_metric(summary_df, level, metric, save_path):
    sub = summary_df[summary_df["level"] == level].copy()
    if sub.empty:
        return

    x = np.arange(len(sub))
    means = sub[f"{metric}_mean"].to_numpy() * 100
    stds = sub[f"{metric}_std"].to_numpy() * 100

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(x, means, yerr=stds, capsize=5, edgecolor="black")
    ax.set_xticks(x)
    ax.set_xticklabels(sub["model"], rotation=20, ha="right")
    ax.set_ylabel(f"{metric.replace('_', ' ').title()} (%)")
    ax.set_title(f"{level.title()}-level {metric.replace('_', ' ').title()}")
    ax.set_ylim(0, 105)
    fig.tight_layout()
    fig.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# 8. Main nested/event-grouped CV
# ============================================================

def build_model_configs():
    """
    Final fair-comparison design.

    Primary architecture comparison:
      CNN, CNN-LSTM, Transformer, CNN-Transformer
    are all trained WITHOUT class-weighted sampling.

    Sampling ablation:
      CNN-Transformer vs CNN-Transformer + weighted sampler
    uses the same architecture, same folds, and the same initialization seed.
    """
    return [
        {"name": "CNN", "factory": CNNOnly, "weighted_sampling": False, "primary": True},
        {"name": "CNN-LSTM", "factory": CNNLSTM, "weighted_sampling": False, "primary": True},
        {"name": "Transformer", "factory": PatchTransformer, "weighted_sampling": False, "primary": True},
        {
            "name": "CNN-Transformer",
            "factory": CNNTransformer,
            "weighted_sampling": False,
            "primary": True,
        },
        {
            "name": "CNN-Transformer + weighted sampler",
            "factory": CNNTransformer,
            "weighted_sampling": True,
            "primary": False,
        },
    ]


def summarize_fold_metrics(fold_df):
    metric_names = [
        "accuracy",
        "macro_precision",
        "macro_recall",
        "macro_f1",
        "weighted_f1",
        "balanced_accuracy",
    ]
    rows = []
    for (model, level), g in fold_df.groupby(["model", "level"], sort=False):
        row = {
            "model": model,
            "level": level,
            "params": int(g["params"].iloc[0]),
            "train_time_s_mean": g["train_time_s"].mean(),
            "test_ms_per_segment_mean": g["test_ms_per_segment"].mean(),
        }
        for m in metric_names:
            row[f"{m}_mean"] = g[m].mean()
            row[f"{m}_std"] = g[m].std(ddof=1)
        rows.append(row)
    return pd.DataFrame(rows)


def run_nested_event_grouped_cv():
    ensure_output_dirs()
    set_global_seed(SEED)

    print(f"Using device: {DEVICE}")
    print(f"Output: {OUTPUT_DIR.resolve()}")

    records, events_df = load_component_sequences(BASE_PATH)

    # Save transparent mapping from Excel columns to event/axis IDs.
    index_rows = []
    for r in records:
        index_rows.append({
            "event_id": r["event_id"],
            "sequence_id": r["sequence_id"],
            "label": r["label"],
            "class_name": r["class_name"],
            "axis": r["axis"],
            "source_column": r["source_column"],
            "sequence_length": len(r["signal"]),
        })
    pd.DataFrame(index_rows).to_csv(
        OUTPUT_DIR / "dataset_sequence_index.csv", index=False
    )

    outer_cv = StratifiedKFold(
        n_splits=N_FOLDS, shuffle=True, random_state=SEED
    )

    event_idx = np.arange(len(events_df))
    event_labels = events_df["label"].to_numpy()
    configs = build_model_configs()

    fold_metric_rows = []
    per_class_frames = []
    split_rows = []

    oof = {
        cfg["name"]: {"segment": [], "component": [], "event": []}
        for cfg in configs
    }

    for fold, (dev_idx, test_idx) in enumerate(
        outer_cv.split(event_idx, event_labels), start=1
    ):
        print("\n" + "=" * 80)
        print(f"OUTER FOLD {fold}/{N_FOLDS}")
        print("=" * 80)

        dev_events = events_df.iloc[dev_idx].reset_index(drop=True)
        test_events = events_df.iloc[test_idx].reset_index(drop=True)

        inner = StratifiedShuffleSplit(
            n_splits=1,
            test_size=INNER_VAL_RATIO,
            random_state=SEED + fold,
        )
        pos = np.arange(len(dev_events))
        tr_pos, va_pos = next(inner.split(pos, dev_events["label"].to_numpy()))

        train_events = dev_events.iloc[tr_pos].reset_index(drop=True)
        val_events = dev_events.iloc[va_pos].reset_index(drop=True)

        train_ids = train_events["event_id"].tolist()
        val_ids = val_events["event_id"].tolist()
        test_ids = test_events["event_id"].tolist()

        assert set(train_ids).isdisjoint(val_ids)
        assert set(train_ids).isdisjoint(test_ids)
        assert set(val_ids).isdisjoint(test_ids)

        print(
            f"Events: train={len(train_ids)}, "
            f"inner-val={len(val_ids)}, outer-test={len(test_ids)}"
        )
        print("Outer-test events/class:", test_events.groupby("class_name").size().to_dict())

        for role, frame in [
            ("train", train_events),
            ("inner_validation", val_events),
            ("outer_test", test_events),
        ]:
            for _, row in frame.iterrows():
                split_rows.append({
                    "fold": fold,
                    "role": role,
                    "event_id": row["event_id"],
                    "label": int(row["label"]),
                    "class_name": row["class_name"],
                })

        train_bundle = segment_records(select_records(records, train_ids))
        val_bundle = segment_records(select_records(records, val_ids))
        test_bundle = segment_records(select_records(records, test_ids))

        print(
            f"Segments: train={len(train_bundle['y'])}, "
            f"inner-val={len(val_bundle['y'])}, "
            f"outer-test={len(test_bundle['y'])}"
        )
        print(
            "Train segment counts:",
            np.bincount(train_bundle["y"], minlength=N_CLASSES).tolist(),
        )
        print(
            "Test segment counts:",
            np.bincount(test_bundle["y"], minlength=N_CLASSES).tolist(),
        )

        for model_i, cfg in enumerate(configs):
            model_name = cfg["name"]
            model_seed = SEED + fold * 100

            print("\n" + "-" * 80)
            print(
                f"{model_name} | weighted_sampling={cfg['weighted_sampling']}"
            )
            print("-" * 80)

            set_global_seed(model_seed)
            model = cfg["factory"]().to(DEVICE)
            params = sum(p.numel() for p in model.parameters() if p.requires_grad)
            print(f"Trainable parameters: {params:,}")

            model, train_info = train_with_inner_validation(
                model,
                train_bundle,
                val_bundle,
                cfg["weighted_sampling"],
                model_seed,
                model_name,
                fold,
            )

            # OUTER TEST IS FIRST TOUCHED HERE.
            test_result = evaluate_loader(model, make_eval_loader(test_bundle))

            seg_df = prediction_dataframe(test_bundle, test_result["probs"])
            comp_df = aggregate_component_predictions(seg_df)
            event_df = aggregate_event_predictions(comp_df)

            prefix = f"fold{fold}_{sanitize_filename(model_name)}"
            seg_df.to_csv(PREDICTION_DIR / f"{prefix}_segment.csv", index=False)
            comp_df.to_csv(PREDICTION_DIR / f"{prefix}_component.csv", index=False)
            event_df.to_csv(PREDICTION_DIR / f"{prefix}_event.csv", index=False)

            level_tables = {
                "segment": seg_df,
                "component": comp_df,
                "event": event_df,
            }

            for level, df in level_tables.items():
                metrics = compute_metrics(
                    df["label"].to_numpy(),
                    df["pred"].to_numpy(),
                )
                fold_metric_rows.append({
                    "model": model_name,
                    "level": level,
                    "fold": fold,
                    **metrics,
                    "params": params,
                    "weighted_sampling": cfg["weighted_sampling"],
                    "best_epoch": train_info["best_epoch"],
                    "best_inner_val_macro_f1": train_info["best_inner_val_macro_f1"],
                    "train_time_s": train_info["train_time_s"],
                    "test_ms_per_segment": test_result["ms_per_sample"],
                })

                per_class_frames.append(
                    per_class_metrics_dataframe(
                        df["label"].to_numpy(),
                        df["pred"].to_numpy(),
                        model_name,
                        level,
                        fold,
                    )
                )

                tmp = df.copy()
                tmp["fold"] = fold
                oof[model_name][level].append(tmp)

            sm = compute_metrics(seg_df["label"], seg_df["pred"])
            em = compute_metrics(event_df["label"], event_df["pred"])
            print(
                f"OUTER segment: Acc={sm['accuracy']*100:.2f}% | "
                f"Macro-F1={sm['macro_f1']*100:.2f}% | "
                f"Weighted-F1={sm['weighted_f1']*100:.2f}%"
            )
            print(
                f"OUTER event:   Acc={em['accuracy']*100:.2f}% | "
                f"Macro-F1={em['macro_f1']*100:.2f}%"
            )

            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    # Save split definitions and fold metrics.
    pd.DataFrame(split_rows).to_csv(
        OUTPUT_DIR / "cv_event_split_assignments.csv", index=False
    )

    fold_df = pd.DataFrame(fold_metric_rows)
    fold_df.to_csv(OUTPUT_DIR / "fold_metrics.csv", index=False)

    per_class_df = pd.concat(per_class_frames, ignore_index=True)
    per_class_df.to_csv(OUTPUT_DIR / "per_class_metrics.csv", index=False)

    summary_df = summarize_fold_metrics(fold_df)
    summary_df.to_csv(OUTPUT_DIR / "summary_mean_std.csv", index=False)

    # Aggregate out-of-fold predictions.
    oof_rows = []
    oof_per_class = []

    for model_name in oof:
        for level in ["segment", "component", "event"]:
            df = pd.concat(oof[model_name][level], ignore_index=True)

            if level == "event" and df["event_id"].duplicated().any():
                raise RuntimeError(
                    f"Duplicate OOF event detected for {model_name}."
                )

            df.to_csv(
                PREDICTION_DIR
                / f"oof_{sanitize_filename(model_name)}_{level}.csv",
                index=False,
            )

            metrics = compute_metrics(df["label"], df["pred"])
            oof_rows.append({
                "model": model_name,
                "level": level,
                **metrics,
            })

            oof_per_class.append(
                per_class_metrics_dataframe(
                    df["label"].to_numpy(),
                    df["pred"].to_numpy(),
                    model_name,
                    level,
                    "OOF",
                )
            )

            cm = confusion_matrix(
                df["label"],
                df["pred"],
                labels=np.arange(N_CLASSES),
            )
            plot_confusion(
                cm,
                f"{model_name} — {level.title()}-level OOF",
                FIGURE_DIR
                / f"cm_{sanitize_filename(model_name)}_{level}.png",
            )

    pd.DataFrame(oof_rows).to_csv(
        OUTPUT_DIR / "oof_metrics.csv", index=False
    )

    oof_per_class_df = pd.concat(oof_per_class, ignore_index=True)
    oof_per_class_df.to_csv(
        OUTPUT_DIR / "oof_per_class_metrics.csv", index=False
    )

    # Generate publication-ready figures/tables using the fair-comparison design.
    generate_publication_outputs(
        summary_df, fold_df, oof_rows, oof_per_class_df, oof
    )

    # Legacy mean ± std comparison figures (kept for audit/reference).
    for level in ["segment", "component", "event"]:
        for metric in ["accuracy", "macro_f1", "weighted_f1"]:
            plot_summary_metric(
                summary_df,
                level,
                metric,
                FIGURE_DIR / f"{level}_{metric}_mean_std.png",
            )

    print("\n" + "=" * 80)
    print("FINAL 5-FOLD SUMMARY")
    print("=" * 80)

    cols = [
        "model",
        "level",
        "accuracy_mean",
        "accuracy_std",
        "macro_f1_mean",
        "macro_f1_std",
        "weighted_f1_mean",
        "weighted_f1_std",
        "balanced_accuracy_mean",
        "balanced_accuracy_std",
    ]
    print(
        summary_df[cols]
        .sort_values(["level", "accuracy_mean"], ascending=[True, False])
        .to_string(index=False)
    )

    print("\nMain output files:")
    for p in [
        OUTPUT_DIR / "dataset_sequence_index.csv",
        OUTPUT_DIR / "cv_event_split_assignments.csv",
        OUTPUT_DIR / "fold_metrics.csv",
        OUTPUT_DIR / "summary_mean_std.csv",
        OUTPUT_DIR / "per_class_metrics.csv",
        OUTPUT_DIR / "oof_metrics.csv",
        OUTPUT_DIR / "oof_per_class_metrics.csv",
    ]:
        print(" ", p)

    return {
        "fold_metrics": fold_df,
        "summary": summary_df,
    }


# ============================================================
# 9. Publication-ready manuscript figures and tables
# ============================================================

PRIMARY_MODELS = ["CNN", "CNN-LSTM", "Transformer", "CNN-Transformer"]
WEIGHTED_VARIANT = "CNN-Transformer + weighted sampler"
PROPOSED_MODEL = "CNN-Transformer"

PUB_DIR = OUTPUT_DIR / "manuscript_figures"

# User-requested journal style: Times New Roman, restrained blue-gray-cyan palette.
PUB_COLORS = ["#4C78A8", "#7A8B99", "#5AB0C7", "#2F5597"]
PUB_SAMPLER_COLORS = ["#2F5597", "#5AB0C7"]


def _set_publication_style():
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 11,
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "axes.linewidth": 1.0,
        "figure.dpi": 120,
        "savefig.dpi": 600,
    })


def _save_pub_figure(fig, stem):
    PUB_DIR.mkdir(parents=True, exist_ok=True)
    png = PUB_DIR / f"{stem}.png"
    pdf = PUB_DIR / f"{stem}.pdf"
    fig.savefig(png, dpi=600, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)


def plot_pub_model_comparison(summary_df):
    _set_publication_style()
    sub = summary_df[
        (summary_df["level"] == "segment") &
        (summary_df["model"].isin(PRIMARY_MODELS))
    ].copy()
    sub["model"] = pd.Categorical(sub["model"], PRIMARY_MODELS, ordered=True)
    sub = sub.sort_values("model")

    x = np.arange(len(sub))
    width = 0.34
    acc = sub["accuracy_mean"].to_numpy() * 100
    acc_std = sub["accuracy_std"].to_numpy() * 100
    mf1 = sub["macro_f1_mean"].to_numpy() * 100
    mf1_std = sub["macro_f1_std"].to_numpy() * 100

    fig, ax = plt.subplots(figsize=(8.8, 5.0))
    ax.bar(x - width/2, acc, width, yerr=acc_std, capsize=4,
           color=PUB_COLORS[0], edgecolor="black", linewidth=0.8,
           label="Accuracy")
    ax.bar(x + width/2, mf1, width, yerr=mf1_std, capsize=4,
           color=PUB_COLORS[2], edgecolor="black", linewidth=0.8,
           label="Macro-F1")
    ax.set_xticks(x)
    ax.set_xticklabels(PRIMARY_MODELS, rotation=12, ha="right")
    ax.set_ylabel("Score (%)")
    ax.set_ylim(80, 101)
    ax.legend(frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    _save_pub_figure(fig, "Fig_model_comparison_segment")


def plot_pub_foldwise_macro_f1(fold_df):
    _set_publication_style()
    sub = fold_df[
        (fold_df["level"] == "segment") &
        (fold_df["model"].isin(PRIMARY_MODELS))
    ].copy()
    pivot = sub.pivot(index="fold", columns="model", values="macro_f1")

    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    for i, model in enumerate(PRIMARY_MODELS):
        ax.plot(
            pivot.index,
            pivot[model].to_numpy() * 100,
            marker="o",
            linewidth=1.8,
            markersize=5,
            color=PUB_COLORS[i],
            label=model,
        )
    ax.set_xlabel("Fold")
    ax.set_ylabel("Macro-F1 (%)")
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_ylim(80, 101)
    ax.legend(frameon=False, ncol=2)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    _save_pub_figure(fig, "Fig_foldwise_segment_macro_f1")


def plot_pub_per_class_f1(oof_per_class_df):
    _set_publication_style()
    sub = oof_per_class_df[
        (oof_per_class_df["level"] == "segment") &
        (oof_per_class_df["fold"].astype(str) == "OOF") &
        (oof_per_class_df["model"].isin(PRIMARY_MODELS))
    ].copy()
    class_order = [
        "Pipeline Blast", "Tunnel Blast", "Collapse Vibration", "Bench Blast"
    ]
    pivot = sub.pivot(index="class_name", columns="model", values="f1")
    pivot = pivot.reindex(class_order)

    x = np.arange(len(class_order))
    width = 0.18
    fig, ax = plt.subplots(figsize=(9.2, 5.0))
    for i, model in enumerate(PRIMARY_MODELS):
        ax.bar(
            x + (i - 1.5) * width,
            pivot[model].to_numpy() * 100,
            width,
            color=PUB_COLORS[i],
            edgecolor="black",
            linewidth=0.7,
            label=model,
        )
    ax.set_xticks(x)
    ax.set_xticklabels(["Pipeline", "Tunnel", "Collapse", "Bench"])
    ax.set_ylabel("F1-score (%)")
    ax.set_ylim(70, 101)
    ax.legend(frameon=False, ncol=2)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    _save_pub_figure(fig, "Fig_per_class_segment_f1")


def plot_pub_sampler_ablation(summary_df):
    _set_publication_style()
    names = [PROPOSED_MODEL, WEIGHTED_VARIANT]
    sub = summary_df[
        (summary_df["level"] == "segment") &
        (summary_df["model"].isin(names))
    ].copy()
    sub["model"] = pd.Categorical(sub["model"], names, ordered=True)
    sub = sub.sort_values("model")

    x = np.arange(2)
    width = 0.34
    acc = sub["accuracy_mean"].to_numpy() * 100
    acc_std = sub["accuracy_std"].to_numpy() * 100
    mf1 = sub["macro_f1_mean"].to_numpy() * 100
    mf1_std = sub["macro_f1_std"].to_numpy() * 100

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.bar(x - width/2, acc, width, yerr=acc_std, capsize=4,
           color=PUB_SAMPLER_COLORS[0], edgecolor="black", linewidth=0.8,
           label="Accuracy")
    ax.bar(x + width/2, mf1, width, yerr=mf1_std, capsize=4,
           color=PUB_SAMPLER_COLORS[1], edgecolor="black", linewidth=0.8,
           label="Macro-F1")
    ax.set_xticks(x)
    ax.set_xticklabels(["Without weighted\nsampling", "With weighted\nsampling"])
    ax.set_ylabel("Score (%)")
    ax.set_ylim(85, 101)
    ax.legend(frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    _save_pub_figure(fig, "Fig_weighted_sampler_ablation")


def plot_pub_confusion_from_df(df, level, stem):
    _set_publication_style()
    y_true = df["label"].to_numpy()
    y_pred = df["pred"].to_numpy()
    cm = confusion_matrix(y_true, y_pred, labels=np.arange(N_CLASSES))
    norm = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)

    short_names = ["Pipeline Blast", "Tunnel Blast", "Collapse Vibration", "Bench Blast"]
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.7))

    for ax, mat, normalized, panel in [
        (axes[0], cm, False, "(a)"),
        (axes[1], norm, True, "(b)"),
    ]:
        im = ax.imshow(mat, cmap="Blues", vmin=0, vmax=(1 if normalized else None))
        ax.set_xticks(np.arange(N_CLASSES))
        ax.set_yticks(np.arange(N_CLASSES))
        ax.set_xticklabels(short_names, rotation=28, ha="right")
        ax.set_yticklabels(short_names)
        ax.set_xlabel("Predicted class")
        ax.set_ylabel("True class")
        ax.text(-0.13, 1.04, panel, transform=ax.transAxes, fontsize=12)

        for i in range(N_CLASSES):
            for j in range(N_CLASSES):
                val = mat[i, j]
                label = f"{val:.3f}" if normalized else f"{int(val)}"
                threshold = 0.5 if normalized else (cm.max() / 2.0)
                ax.text(j, i, label, ha="center", va="center",
                        color="white" if val > threshold else "black", fontsize=9)
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label("Proportion" if normalized else "Number of samples")

    fig.tight_layout()
    _save_pub_figure(fig, stem)


def export_manuscript_tables(summary_df, oof_df, oof_per_class_df):
    PUB_DIR.mkdir(parents=True, exist_ok=True)

    # Primary architecture comparison: identical no-sampler training policy.
    t1 = summary_df[
        (summary_df["level"] == "segment") &
        (summary_df["model"].isin(PRIMARY_MODELS))
    ][[
        "model", "params",
        "accuracy_mean", "accuracy_std",
        "macro_f1_mean", "macro_f1_std",
        "weighted_f1_mean", "weighted_f1_std",
        "balanced_accuracy_mean", "balanced_accuracy_std",
    ]].copy()
    t1.to_csv(PUB_DIR / "Table_primary_architecture_comparison.csv", index=False)

    # Proposed model at three aggregation levels.
    t2 = summary_df[summary_df["model"] == PROPOSED_MODEL][[
        "level", "accuracy_mean", "accuracy_std",
        "macro_f1_mean", "macro_f1_std",
        "weighted_f1_mean", "weighted_f1_std",
        "balanced_accuracy_mean", "balanced_accuracy_std",
    ]].copy()
    t2.to_csv(PUB_DIR / "Table_proposed_multilevel_performance.csv", index=False)

    # Sampler ablation.
    t3 = summary_df[
        (summary_df["level"] == "segment") &
        (summary_df["model"].isin([PROPOSED_MODEL, WEIGHTED_VARIANT]))
    ][[
        "model", "accuracy_mean", "accuracy_std",
        "macro_precision_mean", "macro_precision_std",
        "macro_recall_mean", "macro_recall_std",
        "macro_f1_mean", "macro_f1_std",
        "weighted_f1_mean", "weighted_f1_std",
        "balanced_accuracy_mean", "balanced_accuracy_std",
    ]].copy()
    t3.to_csv(PUB_DIR / "Table_sampler_ablation.csv", index=False)

    # Proposed per-class OOF results.
    t4 = oof_per_class_df[
        (oof_per_class_df["model"] == PROPOSED_MODEL) &
        (oof_per_class_df["level"] == "segment") &
        (oof_per_class_df["fold"].astype(str) == "OOF")
    ].copy()
    t4.to_csv(PUB_DIR / "Table_proposed_per_class_oof.csv", index=False)


def generate_publication_outputs(summary_df, fold_df, oof_rows, oof_per_class_df, oof_dict):
    """Generate all manuscript figures/tables after training finishes."""
    oof_df = pd.DataFrame(oof_rows)
    plot_pub_model_comparison(summary_df)
    plot_pub_foldwise_macro_f1(fold_df)
    plot_pub_per_class_f1(oof_per_class_df)
    plot_pub_sampler_ablation(summary_df)

    for level in ["segment", "component", "event"]:
        df = pd.concat(oof_dict[PROPOSED_MODEL][level], ignore_index=True)
        plot_pub_confusion_from_df(
            df,
            level,
            f"Fig_confusion_{level}",
        )

    export_manuscript_tables(summary_df, oof_df, oof_per_class_df)
    print(f"Publication figures/tables saved to: {PUB_DIR.resolve()}")


if __name__ == "__main__":
    try:
        print("=" * 80)
        print("Blasting Vibration Classification — Final Fair Revision Experiment")
        print("=" * 80)
        print(f"Device: {DEVICE}")
        print(f"Outer folds: {N_FOLDS}")
        print(f"Inner validation ratio: {INNER_VAL_RATIO}")
        print(f"Window: {WINDOW_SIZE} points = {WINDOW_SIZE / FS:.2f} s")
        print(f"Stride: {STRIDE}")
        print(
            f"Transformer: d_model={D_MODEL}, heads={NHEAD}, "
            f"layers={NUM_LAYERS}, FFN={FFN_DIM}"
        )
        print(
            f"Epochs={NUM_EPOCHS}, patience={PATIENCE}, "
            f"batch={BATCH_SIZE}"
        )
        print("=" * 80)

        run_nested_event_grouped_cv()
        print("\nAll experiments completed successfully.")

    except Exception as exc:
        print(f"\nERROR: {exc}")
        import traceback
        traceback.print_exc()
