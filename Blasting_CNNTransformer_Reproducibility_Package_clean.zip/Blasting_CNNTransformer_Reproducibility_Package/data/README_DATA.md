# Data requirements — raw field files NOT distributed

The training scripts require four original Excel workbooks named exactly:

- `管道爆破.xlsx` — 80,000 rows × 90 columns
- `隧道爆破.xlsx` — 8,000 rows × 90 columns
- `塌落振动.xlsx` — 160,000 rows × 90 columns
- `台阶爆破.xlsx` — 16,000 rows × 90 columns

Each workbook must have **no header row**, and columns must be ordered `X, Y, Z` for event 1, then `X, Y, Z` for event 2, ..., for 30 physical events per class. All entries are raw one-dimensional three-axis measured velocity components. The final script considers each component a separate input sequence, but groups all axes and derived windows **by the same physical-event ID** before any split.

A single acquisition event has exactly three co-sampled axes. Measurements should be sampled at 2,000 Hz and all three axes of one event must have equal recording lengths. Do not reorder columns, randomly shuffle segments before physical-event grouping, or augment by copying a single axis into others.

The ZIP does **not** contain the measurement files, and includes no synthetic substitute masquerading as original measurements.

You may use `python tools/validate_data.py --data-dir data` to verify workbook dimensions and grouping expectations. Scientific provenance and sensor calibration cannot be validated from XLSX shapes alone.
