# -*- coding: utf-8 -*-
"""
Generate manuscript-ready figures from an existing revision_results directory.
No model retraining is performed.

This version is compatible with the filenames produced by
train_revision_nested_event_cv.py:
    predictions/oof_<model>_<level>.csv
It also supports the older *_predictions.csv naming as a fallback.
"""

import re
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

# ========================== USER PATH ==========================
RESULTS_DIR = Path(r"revision_results")
# ===============================================================

PRED_DIR = RESULTS_DIR / "predictions"
OUT_DIR = RESULTS_DIR / "manuscript_figures"

CLASS_NAMES = [
    "Pipeline Blast",
    "Tunnel Blast",
    "Collapse Vibration",
    "Bench Blast",
]

PROPOSED_MODEL = "CNN-Transformer (no sampler)"
MODELS = [
    "CNN",
    "CNN-LSTM",
    "Transformer",
    "CNN-Transformer",
    "CNN-Transformer (no sampler)",
]

# Publication-oriented typography.
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 10
plt.rcParams["axes.labelsize"] = 10
plt.rcParams["xtick.labelsize"] = 9
plt.rcParams["ytick.labelsize"] = 9
plt.rcParams["legend.fontsize"] = 9
plt.rcParams["figure.dpi"] = 120
plt.rcParams["savefig.dpi"] = 600


def sanitize_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).replace(" ", "_")


def ensure_dirs():
    OUT_DIR.mkdir(parents=True, exist_ok=True)


def load_table(name: str) -> pd.DataFrame:
    path = RESULTS_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"Missing required result file: {path}")
    return pd.read_csv(path)


def load_oof_prediction(model_name: str, level: str) -> pd.DataFrame:
    """Load OOF predictions using the actual training-script filename first."""
    safe = sanitize_filename(model_name)
    candidates = [
        PRED_DIR / f"oof_{safe}_{level}.csv",                 # actual training output
        PRED_DIR / f"oof_{safe}_{level}_predictions.csv",     # backward-compatible fallback
    ]

    for path in candidates:
        if path.exists():
            print(f"Loaded: {path}")
            return pd.read_csv(path)

    # Helpful diagnostic: show nearby files rather than failing mysteriously.
    nearby = []
    if PRED_DIR.exists():
        nearby = sorted(p.name for p in PRED_DIR.glob(f"oof_{safe}_*.csv"))

    raise FileNotFoundError(
        "Could not find the OOF prediction CSV for:\n"
        f"  model = {model_name}\n"
        f"  level = {level}\n\n"
        "Checked:\n  "
        + "\n  ".join(str(p) for p in candidates)
        + ("\n\nNearby files:\n  " + "\n  ".join(nearby) if nearby else "")
    )


def _annotate_matrix(ax, mat, normalized=False):
    threshold = (mat.max() + mat.min()) / 2.0 if mat.size else 0
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            text = f"{mat[i, j]:.3f}" if normalized else f"{int(mat[i, j])}"
            ax.text(
                j, i, text,
                ha="center", va="center",
                fontsize=9,
                color="white" if mat[i, j] > threshold else "black",
            )


def plot_confusion_pair(df: pd.DataFrame, model_name: str, level: str) -> Path:
    """Count and row-normalized confusion matrices in one publication figure."""
    y_true = df["label"].to_numpy(dtype=int)
    y_pred = df["pred"].to_numpy(dtype=int)

    cm = confusion_matrix(y_true, y_pred, labels=np.arange(4))
    denom = np.maximum(cm.sum(axis=1, keepdims=True), 1)
    cm_norm = cm.astype(float) / denom

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.4))

    im0 = axes[0].imshow(cm, cmap="Blues")
    _annotate_matrix(axes[0], cm, normalized=False)
    axes[0].text(-0.13, 1.04, "(a)", transform=axes[0].transAxes, fontsize=11)

    im1 = axes[1].imshow(cm_norm, cmap="Blues", vmin=0, vmax=1)
    _annotate_matrix(axes[1], cm_norm, normalized=True)
    axes[1].text(-0.13, 1.04, "(b)", transform=axes[1].transAxes, fontsize=11)

    for ax in axes:
        ax.set_xticks(np.arange(4))
        ax.set_yticks(np.arange(4))
        ax.set_xticklabels(CLASS_NAMES, rotation=28, ha="right")
        ax.set_yticklabels(CLASS_NAMES)
        ax.set_xlabel("Predicted class")
        ax.set_ylabel("True class")

    # No internal figure title/caption; caption belongs in manuscript.
    cbar0 = fig.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)
    cbar0.ax.set_ylabel("Number of samples", rotation=90)
    cbar1 = fig.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)
    cbar1.ax.set_ylabel("Proportion", rotation=90)

    fig.tight_layout()
    path = OUT_DIR / f"confusion_{sanitize_filename(model_name)}_{level}.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def plot_model_comparison(summary: pd.DataFrame) -> Path:
    sub = summary[(summary["level"] == "segment") & summary["model"].isin(MODELS)].copy()
    order = [m for m in MODELS if m in set(sub["model"])]
    sub["model"] = pd.Categorical(sub["model"], categories=order, ordered=True)
    sub = sub.sort_values("model")

    x = np.arange(len(sub))
    width = 0.36

    acc = sub["accuracy_mean"].to_numpy() * 100
    acc_std = sub["accuracy_std"].to_numpy() * 100
    mf1 = sub["macro_f1_mean"].to_numpy() * 100
    mf1_std = sub["macro_f1_std"].to_numpy() * 100

    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    ax.bar(x - width/2, acc, width, yerr=acc_std, capsize=3, label="Accuracy", edgecolor="black")
    ax.bar(x + width/2, mf1, width, yerr=mf1_std, capsize=3, label="Macro-F1", edgecolor="black")

    ax.set_xticks(x)
    ax.set_xticklabels(sub["model"].astype(str), rotation=18, ha="right")
    ax.set_ylabel("Score (%)")
    ax.set_ylim(88, 101)
    ax.legend(frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    path = OUT_DIR / "segment_model_comparison.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def plot_sampler_ablation(summary: pd.DataFrame) -> Path:
    names = ["CNN-Transformer", "CNN-Transformer (no sampler)"]
    sub = summary[(summary["level"] == "segment") & summary["model"].isin(names)].copy()
    sub["model"] = pd.Categorical(sub["model"], categories=names, ordered=True)
    sub = sub.sort_values("model")

    x = np.arange(len(sub))
    width = 0.36

    acc = sub["accuracy_mean"].to_numpy() * 100
    acc_std = sub["accuracy_std"].to_numpy() * 100
    mf1 = sub["macro_f1_mean"].to_numpy() * 100
    mf1_std = sub["macro_f1_std"].to_numpy() * 100

    fig, ax = plt.subplots(figsize=(6.4, 4.5))
    ax.bar(x - width/2, acc, width, yerr=acc_std, capsize=3, label="Accuracy", edgecolor="black")
    ax.bar(x + width/2, mf1, width, yerr=mf1_std, capsize=3, label="Macro-F1", edgecolor="black")
    ax.set_xticks(x)
    ax.set_xticklabels(["With weighted\nsampling", "Without weighted\nsampling"])
    ax.set_ylabel("Score (%)")
    ax.set_ylim(90, 101)
    ax.legend(frameon=False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    path = OUT_DIR / "weighted_sampler_ablation.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def plot_foldwise_macro_f1(fold: pd.DataFrame) -> Path:
    sub = fold[(fold["level"] == "segment") & fold["model"].isin(MODELS)].copy()
    pivot = sub.pivot(index="fold", columns="model", values="macro_f1")
    pivot = pivot[[m for m in MODELS if m in pivot.columns]]

    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    for name in pivot.columns:
        ax.plot(pivot.index, pivot[name] * 100, marker="o", linewidth=1.5, label=name)

    ax.set_xlabel("Fold")
    ax.set_ylabel("Macro-F1 (%)")
    ax.set_xticks(sorted(pivot.index.tolist()))
    ax.set_ylim(85, 101)
    ax.legend(frameon=False, fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    path = OUT_DIR / "foldwise_segment_macro_f1.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def plot_per_class_f1(oof_per_class: pd.DataFrame) -> Path:
    sub = oof_per_class[
        (oof_per_class["level"] == "segment") &
        (oof_per_class["fold"].astype(str).str.upper() == "OOF") &
        (oof_per_class["model"].isin(MODELS))
    ].copy()

    if sub.empty:
        # Some pandas versions may convert mixed fold values in a way that makes
        # OOF filtering inconvenient. Fall back to rows whose fold is not numeric.
        tmp = oof_per_class[(oof_per_class["level"] == "segment") & oof_per_class["model"].isin(MODELS)].copy()
        non_numeric = pd.to_numeric(tmp["fold"], errors="coerce").isna()
        sub = tmp[non_numeric]

    pivot = sub.pivot(index="class_name", columns="model", values="f1")
    pivot = pivot.reindex(CLASS_NAMES)
    pivot = pivot[[m for m in MODELS if m in pivot.columns]]

    x = np.arange(4)
    n = len(pivot.columns)
    width = 0.82 / max(n, 1)

    fig, ax = plt.subplots(figsize=(9.6, 4.8))
    for i, name in enumerate(pivot.columns):
        ax.bar(x - 0.41 + width/2 + i*width, pivot[name].to_numpy()*100, width, label=name, edgecolor="black")

    ax.set_xticks(x)
    ax.set_xticklabels(CLASS_NAMES)
    ax.set_ylabel("F1-score (%)")
    ax.set_ylim(75, 101)
    ax.legend(frameon=False, fontsize=8, ncol=2)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    path = OUT_DIR / "segment_per_class_f1.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def export_key_results(summary: pd.DataFrame, oof_metrics: pd.DataFrame) -> Path:
    seg = summary[summary["level"] == "segment"].sort_values("macro_f1_mean", ascending=False)
    best = seg.iloc[0]

    oof_row = oof_metrics[
        (oof_metrics["model"] == PROPOSED_MODEL) &
        (oof_metrics["level"] == "segment")
    ]

    text = [
        "# Key results for manuscript revision",
        "",
        f"Recommended final model: **{PROPOSED_MODEL}**",
        "",
        "## Five-fold mean ± standard deviation (segment level)",
        f"- Accuracy: **{best['accuracy_mean']*100:.2f}% ± {best['accuracy_std']*100:.2f}%**",
        f"- Macro-F1: **{best['macro_f1_mean']*100:.2f}% ± {best['macro_f1_std']*100:.2f}%**",
        f"- Weighted F1: **{best['weighted_f1_mean']*100:.2f}% ± {best['weighted_f1_std']*100:.2f}%**",
        f"- Balanced Accuracy: **{best['balanced_accuracy_mean']*100:.2f}% ± {best['balanced_accuracy_std']*100:.2f}%**",
    ]

    if not oof_row.empty:
        r = oof_row.iloc[0]
        text += [
            "",
            "## Combined out-of-fold result (segment level)",
            f"- Accuracy: **{r['accuracy']*100:.2f}%**",
            f"- Macro-F1: **{r['macro_f1']*100:.2f}%**",
            f"- Weighted F1: **{r['weighted_f1']*100:.2f}%**",
            f"- Balanced Accuracy: **{r['balanced_accuracy']*100:.2f}%**",
        ]

    text += [
        "",
        "## Interpretation",
        "The no-sampler CNN-Transformer is recommended as the final proposed configuration because it achieved the best segment-level mean performance under physical-event-grouped nested cross-validation. Weighted random sampling should therefore be reported as an ablation/training-strategy comparison rather than as a mandatory component of the final method.",
    ]

    path = OUT_DIR / "key_results_for_manuscript.md"
    path.write_text("\n".join(text), encoding="utf-8")
    return path


def main():
    ensure_dirs()

    summary = load_table("summary_mean_std.csv")
    fold = load_table("fold_metrics.csv")
    oof_metrics = load_table("oof_metrics.csv")
    oof_per_class = load_table("oof_per_class_metrics.csv")

    outputs = []
    outputs.append(plot_model_comparison(summary))
    outputs.append(plot_sampler_ablation(summary))
    outputs.append(plot_foldwise_macro_f1(fold))
    outputs.append(plot_per_class_f1(oof_per_class))

    # Main manuscript confusion matrix: best final model, segment level.
    proposed_seg = load_oof_prediction(PROPOSED_MODEL, "segment")
    outputs.append(plot_confusion_pair(proposed_seg, PROPOSED_MODEL, "segment"))

    # Optional component/event matrices: useful for supplementary engineering evidence.
    for level in ["component", "event"]:
        df = load_oof_prediction(PROPOSED_MODEL, level)
        outputs.append(plot_confusion_pair(df, PROPOSED_MODEL, level))

    outputs.append(export_key_results(summary, oof_metrics))

    print("\nDone. Generated:")
    for p in outputs:
        print("  ", p)


if __name__ == "__main__":
    main()
