# -*- coding: utf-8 -*-
"""Fast, read-only XLSX shape preflight; not a validation of scientific provenance."""
import argparse
from pathlib import Path
from openpyxl import load_workbook

FILES = [
    ('管道爆破.xlsx', 80000),
    ('隧道爆破.xlsx', 8000),
    ('塌落振动.xlsx', 160000),
    ('台阶爆破.xlsx', 16000),
]


def validate_data_dir(directory: Path):
    directory = Path(directory).expanduser().resolve()
    if not directory.is_dir():
        raise FileNotFoundError(f'Data directory not found: {directory}')
    print(f'Checking measurement data in {directory}')
    for name, expected_rows in FILES:
        path = directory / name
        if not path.is_file():
            raise FileNotFoundError(f'Missing workbook: {path}')
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            if not wb.worksheets:
                raise ValueError(f'Empty XLSX file: {path}')
            ws = wb.worksheets[0]
            rows, cols = ws.max_row, ws.max_column
            if rows != expected_rows or cols != 90:
                raise ValueError(
                    f'{name}: expected {expected_rows:,} rows × 90 columns; '
                    f'found {rows:,} × {cols}. Header rows/extra columns are not allowed.'
                )
            print(f'  OK {name}: {rows:,} rows × {cols} columns = 30 X/Y/Z events')
        finally:
            wb.close()
    print('XLSX dimension preflight passed (120 events; 360 axes; 11,880 expected 1-second windows).')
    return True


def main():
    parser = argparse.ArgumentParser(description='Validate final-study Excel workbook dimensions.')
    parser.add_argument('--data-dir', type=Path, default=Path(__file__).resolve().parents[1] / 'data')
    args = parser.parse_args()
    validate_data_dir(args.data_dir)


if __name__ == '__main__':
    main()
