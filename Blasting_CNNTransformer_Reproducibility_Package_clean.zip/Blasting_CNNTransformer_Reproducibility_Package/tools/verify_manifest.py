# -*- coding: utf-8 -*-
"""Compare SHA-256 hashes against the package manifest."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'MANIFEST_SHA256.txt'


def main():
    errors = []
    lines = [line for line in MANIFEST.read_text(encoding='utf-8').splitlines() if line.strip() and not line.startswith('#')]
    for line in lines:
        expected, path_str = line.split('  ', 1)
        path = ROOT / path_str
        if not path.is_file():
            errors.append(f'MISSING {path_str}')
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected != actual:
            errors.append(f'HASH MISMATCH {path_str}')
    if errors:
        for error in errors:
            print(error)
        raise SystemExit(1)
    print(f'PASS: Verified {len(lines)} package file SHA-256 checksums.')


if __name__=='__main__':
    main()
