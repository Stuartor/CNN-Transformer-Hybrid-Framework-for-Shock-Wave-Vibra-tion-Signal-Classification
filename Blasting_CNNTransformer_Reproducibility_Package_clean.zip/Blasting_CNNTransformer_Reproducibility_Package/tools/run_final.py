# -*- coding: utf-8 -*-
"""Portable launcher: runs the *unchanged* uploaded final fair experiment."""
import argparse
import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_original():
    location = ROOT / 'train_revision_final_fair.py'
    spec = importlib.util.spec_from_file_location('final_fair_experiment', location)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main():
    ap = argparse.ArgumentParser(description='Run the original final fair-comparison experiment with portable paths.')
    ap.add_argument('--data-dir', type=Path, default=ROOT / 'data', help='Folder containing four original Chinese-named XLSX files.')
    ap.add_argument('--output-dir', type=Path, default=ROOT / 'revision_results_fair', help='New output directory.')
    ap.add_argument('--skip-data-check', action='store_true', help='Skip the read-only XLSX dimension preflight.')
    args = ap.parse_args()

    data_dir = args.data_dir.expanduser().resolve()
    out_dir = args.output_dir.expanduser().resolve()
    if not args.skip_data_check:
        from validate_data import validate_data_dir
        validate_data_dir(data_dir)
    elif not data_dir.is_dir():
        ap.error(f'Data directory does not exist: {data_dir}')

    mod = load_original()
    # Override path constants ONLY. All model and training hyperparameters, seeds,
    # splits, aggregation rules, and plotting methods remain from the original file.
    mod.BASE_PATH = str(data_dir)
    mod.OUTPUT_DIR = out_dir
    mod.CHECKPOINT_DIR = out_dir / 'checkpoints'
    mod.HISTORY_DIR = out_dir / 'histories'
    mod.PREDICTION_DIR = out_dir / 'predictions'
    mod.FIGURE_DIR = out_dir / 'figures'
    mod.PUB_DIR = out_dir / 'manuscript_figures'

    print('Running final fair-comparison code without modifying uploaded source.')
    print(f'Input:  {data_dir}')
    print(f'Output: {out_dir}')
    print(f'Device: {mod.DEVICE}')
    mod.run_nested_event_grouped_cv()
    print('Final fair-comparison experiment completed successfully.')


if __name__ == '__main__':
    main()
