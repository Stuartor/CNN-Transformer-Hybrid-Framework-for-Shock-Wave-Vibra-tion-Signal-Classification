# -*- coding: utf-8 -*-
"""Capture machine/version metadata. Does not upload data or contact any server."""
import argparse
import importlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, default=Path('environment_actual.json'))
    args = ap.parse_args()
    result = {
        'captured_utc': datetime.now(timezone.utc).isoformat(),
        'python': sys.version,
        'platform': platform.platform(),
        'packages': {},
    }
    for name in ['torch', 'numpy', 'pandas', 'sklearn', 'scipy', 'matplotlib', 'openpyxl']:
        try:
            mod = importlib.import_module(name)
            result['packages'][name] = getattr(mod, '__version__', 'unknown')
        except Exception as e:
            result['packages'][name] = f'UNAVAILABLE: {type(e).__name__}'
    try:
        import torch
        result['torch_cuda_version'] = torch.version.cuda
        result['cuda_available'] = torch.cuda.is_available()
        result['cudnn_version'] = torch.backends.cudnn.version() if torch.cuda.is_available() else None
        if torch.cuda.is_available():
            result['gpu'] = torch.cuda.get_device_name(0)
    except Exception:
        pass
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Saved environment metadata to {args.output.resolve()}')


if __name__ == '__main__':
    main()
