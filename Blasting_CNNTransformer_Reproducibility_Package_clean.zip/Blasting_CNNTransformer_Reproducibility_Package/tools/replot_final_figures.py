# -*- coding: utf-8 -*-
"""Rebuild fair-study figures from saved OOF prediction CSVs (NO retraining)."""
import argparse
import importlib.util
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description='Regenerate final fair study figures from its CSV results.')
    parser.add_argument('--results-dir', type=Path, default=ROOT / 'revision_results_fair')
    args = parser.parse_args()
    results_dir = args.results_dir.expanduser().resolve()
    required = ['summary_mean_std.csv', 'fold_metrics.csv', 'oof_metrics.csv', 'oof_per_class_metrics.csv']
    for name in required:
        if not (results_dir / name).is_file():
            parser.error(f'Required final-results file not found: {results_dir / name}')

    spec = importlib.util.spec_from_file_location('final_fair_for_plotting', ROOT / 'train_revision_final_fair.py')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    mod.OUTPUT_DIR = results_dir
    mod.PUB_DIR = results_dir / 'manuscript_figures'

    summary = pd.read_csv(results_dir / 'summary_mean_std.csv')
    fold = pd.read_csv(results_dir / 'fold_metrics.csv')
    oof_metrics = pd.read_csv(results_dir / 'oof_metrics.csv')
    per_class = pd.read_csv(results_dir / 'oof_per_class_metrics.csv')

    for model in mod.PRIMARY_MODELS + [mod.WEIGHTED_VARIANT]:
        if model not in set(summary['model']):
            parser.error(f'Expected final-fair model {model!r} missing from {results_dir / "summary_mean_std.csv"}; perhaps these are legacy results.')

    mod.plot_pub_model_comparison(summary)
    mod.plot_pub_foldwise_macro_f1(fold)
    mod.plot_pub_per_class_f1(per_class)
    mod.plot_pub_sampler_ablation(summary)
    for level in ['segment', 'component', 'event']:
        file_path = results_dir / 'predictions' / f'oof_{mod.sanitize_filename(mod.PROPOSED_MODEL)}_{level}.csv'
        if not file_path.is_file():
            parser.error(f'Missing final-fair OOF prediction CSV for {level}: {file_path}')
        df = pd.read_csv(file_path)
        mod.plot_pub_confusion_from_df(df, level, f'Fig_confusion_{level}')
    mod.export_manuscript_tables(summary, oof_metrics, per_class)
    print(f'Final fair-study publication figures/tables regenerated at: {mod.PUB_DIR}')


if __name__ == '__main__':
    main()
