# Reproducibility Package: CNN–Transformer Blasting-Vibration Classification

**Paper:** *A CNN–Transformer Hybrid Framework for Shock Wave Vibration Signal Classification in Blasting Engineering*

**Status:** Reproducibility materials for the **final fair-comparison experiment**. The three originally uploaded `.py` scripts are included **byte-for-byte unchanged**. The additional utilities in `tools/` are convenience wrappers; they do not modify the original training algorithm.

> **Important data limitation:** The four field-measurement Excel workbooks and the originally trained model checkpoints are **not included** because they have not been provided in this conversation. This is a reproducible *code-and-protocol package*, not a self-contained reproduction of the numerical results. To reproduce the experimental numbers, you must provide the original data in the exact layout below. Exact numerical identity may also depend on PyTorch/CUDA/GPU library versions and nondeterministic kernels.

## 1. Which script corresponds to the final paper?

| File | Purpose | For final-paper results? |
|---|---|---|
| `train_revision_final_fair.py` | **Main, original final experimental script.** Grouped 5-fold CV, fair baselines, weighted-sampler ablation, figures/tables. | **YES** |
| `train_revision_nested_event_cv.py` | Historical intermediate experiment; its baseline sampling policy differs from the final experiment. | **NO** (audit only) |
| `generate_manuscript_figures_from_revision_results_FIXED.py` | Legacy post-processing utility for the **intermediate** `revision_results/` folder; expects model name `CNN-Transformer (no sampler)`. | **NO** (legacy results only) |
| `tools/run_final.py` | Portable CLI entry point for the unchanged final training script; sets paths without editing it. | Optional convenience |
| `tools/replot_final_figures.py` | Regenerate the **final fair-experiment** publication figures from stored CSVs, without model retraining. | **YES** |
| `tools/validate_data.py` | Read-only spreadsheet layout preflight. | Recommended |
| `tests/smoke_test.py` | Synthetic unit/smoke tests (no real data; **not** a scientific result). | Recommended |

**Do not substitute the legacy plotting script for `tools/replot_final_figures.py`.** The legacy script names and model labels are different and it may fail with the final results.

## 2. Data layout (required for numerical reproduction)

Create the following directory under the extracted package (or pass another folder via `--data-dir`):

```text
Blasting_CNNTransformer_Reproducibility_Package/
├── README.md
├── README_CN.md
├── requirements.txt
├── train_revision_final_fair.py
├── train_revision_nested_event_cv.py
├── generate_manuscript_figures_from_revision_results_FIXED.py
├── tools/
│   ├── run_final.py
│   ├── validate_data.py
│   ├── replot_final_figures.py
│   └── environment_report.py
├── tests/
│   └── smoke_test.py
└── data/
    ├── 管道爆破.xlsx
    ├── 隧道爆破.xlsx
    ├── 塌落振动.xlsx
    └── 台阶爆破.xlsx
```

**Each workbook:** no header; exactly 90 numeric columns, in adjacent groups of three: event 01 X/Y/Z, event 02 X/Y/Z, ..., event 30 X/Y/Z. Thus each category contains 30 independent physical acquisition events. The expected effective sequence lengths per component are:

| Class (file) | Events | Columns | Samples/axis | Duration/axis at 2 kHz | Segments/class |
|---|---:|---:|---:|---:|---:|
| 管道爆破.xlsx (pipeline) | 30 | 90 | 80,000 | 40 s | 3,600 |
| 隧道爆破.xlsx (tunnel) | 30 | 90 | 8,000 | 4 s | 360 |
| 塌落振动.xlsx (collapse) | 30 | 90 | 160,000 | 80 s | 7,200 |
| 台阶爆破.xlsx (bench) | 30 | 90 | 16,000 | 8 s | 720 |
| **Total** | **120** | **360** | — | — | **11,880** |

The class order in the code is **pipeline → tunnel → collapse → bench** (labels 0–3). The input must contain real measured one-dimensional velocity sequences, not artificially tiled or shuffled columns. Preserve the physical-event grouping, and **never** distribute X/Y/Z components of the same event across training/validation/test splits.

See `data/README_DATA.md` for input requirements, privacy considerations, and limitations.

## 3. Installation

Recommended: Python **3.9 or 3.10** in an isolated environment. The originally reported experiments were performed in a Windows/CUDA environment, but the exact historical `pip freeze` was not uploaded; `requirements.txt` is a *suggested compatibility recipe that has not been tested against the original training machine*, **not** an exact original-environment lockfile. Existing environments already providing PyTorch/CUDA may be used instead.

```powershell
conda create -n blasting-repro python=3.9 -y
conda activate blasting-repro
python -m pip install -r requirements.txt
```

If CUDA acceleration is required, install the PyTorch build appropriate for **your GPU/driver/Python** using the official PyTorch installation instructions. Avoid blindly replacing an already functional CUDA-enabled PyTorch installation; the general pip recipe can resolve to a CPU installation on some systems. CPU execution works but is much slower.

Capture actual environment details for your research record:

```powershell
python tools/environment_report.py --output environment_actual.json
python -m pip freeze > pip_freeze_actual.txt
```

## 4. First check inputs and run a smoke test

```powershell
python tools/validate_data.py --data-dir data
python tests/smoke_test.py
```

`validate_data.py` checks the workbook dimensions using `openpyxl` read-only mode. It does **not** certify the scientific provenance or correctness of the input recordings. The original training script performs stronger checks during signal loading and segmentation.

## 5. Reproduce the FINAL grouped-CV training

**Portable entry point (recommended):**

```powershell
python tools/run_final.py --data-dir data --output-dir revision_results_fair
```

To use your historical data path on Windows, for example:

```powershell
python tools/run_final.py --data-dir "path/to/your/data" --output-dir revision_results_fair
```

**Direct original-script execution:** open `train_revision_final_fair.py` and set its `BASE_PATH` at the top to your directory. Then run:

```powershell
python train_revision_final_fair.py
```

The direct script writes to `revision_results_fair/` **relative to the working directory**. The portable wrapper uses an absolute path and puts outputs in the specified folder. These change only file locations, not experimental settings.

Default settings of the unchanged final script:

- `SEED = 42`; outer `StratifiedKFold(n_splits=5, shuffle=True)` **on 120 physical-event IDs**, not segments/axes.
- Within each outer fold: **76 train events, 20 inner-validation events, 24 outer-test events** (6 test events per class); `StratifiedShuffleSplit` selects the inner validation. Outer-test events are not used to select checkpoints/epochs.
- 2 kHz sampling; 2,000-point (1 s) non-overlapping windows; per-segment Z-score normalization.
- Four **no-sampler** architecture baselines: CNN, CNN-LSTM, patch Transformer, CNN–Transformer.
- Separate sampler ablation: CNN–Transformer **with** inverse-frequency `WeightedRandomSampler` vs **without** it, same fold-specific model initialization seed.
- AdamW (`lr=5e-4`, `weight_decay=0.01`), batch size 32, up to 40 epochs, cosine annealing (`T_max=15`), gradient clip 1.0, early-stopping patience 10 based on *inner-validation Macro-F1*.
- CNN channels `[32, 64, 128, 256]`; 4 Transformer heads, 2 encoder layers, `d_model=64`, FFN=256; **temporal mean pooling** after the Transformer.
- Segment, component-sequence, and event probabilities; component = mean segment softmax probabilities, event = equal-weight mean of X/Y/Z component probabilities (late aggregation, **not** trained three-channel sensor fusion).

## 6. Outputs and manuscript-ready figures

After successful training, the output directory contains (among others):

```text
revision_results_fair/
├── summary_mean_std.csv              # fold mean ± sample std (ddof=1)
├── fold_metrics.csv
├── per_class_metrics.csv
├── oof_metrics.csv                  # pooled out-of-fold metrics
├── oof_per_class_metrics.csv
├── dataset_sequence_index.csv
├── cv_event_split_assignments.csv
├── histories/
├── checkpoints/
├── predictions/                     # fold-wise and OOF softmax scores
├── figures/                         # original diagnostic plots
└── manuscript_figures/
    ├── Fig_model_comparison_segment.png/.pdf
    ├── Fig_foldwise_segment_macro_f1.png/.pdf
    ├── Fig_per_class_segment_f1.png/.pdf
    ├── Fig_weighted_sampler_ablation.png/.pdf
    ├── Fig_confusion_segment.png/.pdf
    ├── Fig_confusion_component.png/.pdf
    ├── Fig_confusion_event.png/.pdf
    ├── Table_primary_architecture_comparison.csv
    ├── Table_proposed_multilevel_performance.csv
    ├── Table_sampler_ablation.csv
    └── Table_proposed_per_class_oof.csv
```

If you already have `revision_results_fair/` with the full set of metrics and OOF predictions, **you do not need to retrain just to generate plots**:

```powershell
python tools/replot_final_figures.py --results-dir revision_results_fair
```

`summary_mean_std.csv` shows the **unweighted mean of five fold scores** with fold-to-fold sample standard deviation, not the same quantity as pooled `oof_metrics.csv`. For reproducibility, do not mix or relabel them.

### Reference values from the last completed fair experiment (not computed by this package)

| Configuration | Segment accuracy (5-fold mean ± SD) | Segment Macro-F1 (mean ± SD) |
|---|---:|---:|
| CNN | 97.58 ± 1.30% | 95.99 ± 1.53% |
| CNN–LSTM | 97.85 ± 0.82% | 96.03 ± 1.17% |
| Transformer | 95.57 ± 2.19% | 91.57 ± 4.01% |
| **CNN–Transformer (no sampler; primary)** | **97.97 ± 0.76%** | **96.53 ± 1.11%** |
| CNN–Transformer + weighted sampler | 97.86 ± 1.09% | 97.17 ± 1.45% |

These figures are historical reference values from the previously shared final experiment log. They are not asserted to be recreated here, because the field data and original checkpoints are absent. Different hardware/libraries can yield small deviations.

## 7. Auditability / checksums

- `MANIFEST_SHA256.txt`: checksums of the included project files, including the three unchanged original scripts. You can compare against the manifest with `tools/verify_manifest.py`.
- Original scripts are preserved as uploaded; utility wrappers do not replace or rewrite them.
- `environment_actual.json`, `pip_freeze_actual.txt`, data provenance, and output CSVs are best archived with the research record after an actual run.
- **Data sharing:** Confirm the right to redistribute field data and any site-identifying metadata before publishing a complete archive or depositing it on Zenodo/GitHub. No open-source license has been selected for these scripts; obtain agreement from rights holders before public redistribution.

## 8. Caveats / evidence boundaries

1. Event grouping prevents X/Y/Z and windows from the same measured acquisition entering different folds, but **does not prove generalization to completely unseen sites or geological conditions**.
2. Original data may contain class-correlated environment and site factors; a high grouped-CV score does not by itself establish causal waveform interpretation.
3. The five-fold implementation contains an inner train/validation split for checkpoint choice; it is **not** a comprehensive nested hyperparameter search over a predefined grid. Do not describe it as such in supplementary methods.
4. Benchmarks were run with specific original hardware/software. Training duration and timing output will vary by machine and installation.
5. No original field data, trained weights, historical pip freeze, or full raw output folder have been included; numerical reproduction requires obtaining them separately.
