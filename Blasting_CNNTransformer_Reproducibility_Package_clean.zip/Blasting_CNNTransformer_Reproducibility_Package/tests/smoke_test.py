# -*- coding: utf-8 -*-
"""Synthetic non-training tests of the ORIGINAL final algorithm; not paper results."""
import importlib.util
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('final_fair_smoke', ROOT / 'train_revision_final_fair.py')
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def main():
    torch.set_num_threads(min(2, torch.get_num_threads()))
    assert mod.N_FOLDS == 5 and mod.N_CLASSES == 4
    assert mod.FS == mod.WINDOW_SIZE == mod.STRIDE == 2000
    assert mod.PROPOSED_MODEL == 'CNN-Transformer'
    assert len(mod.PRIMARY_MODELS) == 4

    labels = np.repeat(np.arange(4), 30)
    event_ids = np.asarray([f'C{c}_E{i:03d}' for c in range(4) for i in range(1,31)])
    outer = StratifiedKFold(n_splits=mod.N_FOLDS, shuffle=True, random_state=mod.SEED)
    for fold, (dev, test) in enumerate(outer.split(event_ids, labels), 1):
        assert len(dev) == 96 and len(test) == 24
        assert np.bincount(labels[test], minlength=4).tolist() == [6,6,6,6]
        inner = StratifiedShuffleSplit(n_splits=1, test_size=mod.INNER_VAL_RATIO, random_state=mod.SEED+fold)
        tr, va = next(inner.split(np.arange(len(dev)), labels[dev]))
        assert len(tr) == 76 and len(va) == 20
        assert set(dev[tr]).isdisjoint(set(dev[va]))
        assert set(dev[tr]).isdisjoint(set(test))
        assert set(dev[va]).isdisjoint(set(test))

    # Synthetic 2,000-point windows: 4 events, three axes per event.
    rng = np.random.default_rng(88)
    recs = []
    for c in range(4):
        for axis in mod.AXIS_ORDER:
            recs.append({'signal':rng.normal(size=2000).astype(np.float32),
                         'label':c, 'event_id':f'C{c}_E001',
                         'sequence_id':f'C{c}_E001_{axis}', 'axis':axis})
    bundle = mod.segment_records(recs)
    assert bundle['x'].shape == (12,2000,1)
    assert np.all(np.isfinite(bundle['x']))
    assert len(set(bundle['event_id'])) == 4
    assert np.max(np.abs(bundle['x'].mean(axis=1))) < 0.0001
    onehot = np.eye(4,dtype=np.float32)[bundle['y']]
    seg = mod.prediction_dataframe(bundle, onehot)
    comp = mod.aggregate_component_predictions(seg)
    events = mod.aggregate_event_predictions(comp)
    assert len(comp)==12 and len(events)==4
    assert (events['label']==events['pred']).all()
    assert mod.compute_metrics(events['label'],events['pred'])['accuracy']==1.0

    # Model forward passes (no training): output logits have exactly 4 classes.
    x = torch.tensor(bundle['x'][:2])
    for cls in (mod.CNNOnly,mod.CNNLSTM,mod.PatchTransformer,mod.CNNTransformer):
        model=cls().eval()
        with torch.no_grad():
            logits=model(x)
        assert tuple(logits.shape)==(2,4), (cls.__name__, logits.shape)
        assert bool(torch.isfinite(logits).all())
        print(f'PASS {cls.__name__}: {tuple(logits.shape)}')
    print('PASS grouping, stratified event splits, segmentation, hierarchical probability aggregation, and network forward passes')
    print('NOTE: synthetic checks do NOT reproduce empirical publication metrics.')


if __name__=='__main__':
    main()
